
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------

#include <math.h>

#include <QtCore/QDebug>

#include "thread.h"
#include "moc_thread.cpp"

//------------------------------------------------------------------------------
//------------------------------------------------------------------------------

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

//------------------------------------------------------------------------------
//------------------------------------------------------------------------------

Thread::Thread( int _periode, double * & _voies, QObject * p ) : 
	QThread( p ), 
	periode( _periode ), 
	term( false )
{
	_voies = voies = new double[2];
	qDebug() << "thread &buffer" << voies;
	qDebug() << "thread &time"   << voies;
	qDebug() << "thread &voie"   << voies + 1;
}

//------------------------------------------------------------------------------
//------------------------------------------------------------------------------

Thread::~Thread()
{
}

//------------------------------------------------------------------------------
//------------------------------------------------------------------------------

void Thread::run()
{
	static int    np        = 0;
	static double perSec    = periode / 1000.0;
	// static double freq      = 1 / perSec;
	static double amplitude = 10;
	static double pcBruit   = 0.03;
	while( ! term )
	{
		double temps = np * perSec;
		double bruit = pcBruit * amplitude * (2.0 * qrand() / RAND_MAX - 1);
		// date en secondes
		// sinusoide periode 10 secondes
		voies[0] = temps;
		voies[1] = amplitude * sin( 2 * M_PI / 10 * temps * 5 ) + bruit;
		msleep( periode );
		np++;
	}
}

//------------------------------------------------------------------------------
//------------------------------------------------------------------------------

