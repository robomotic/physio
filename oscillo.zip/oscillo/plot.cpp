
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------

#include "plot.h"
#include "moc_plot.cpp"

#include <QtCore/QDebug>
#include <QtCore/QTimer>
#include <QtCore/QTimerEvent>

#include "qwt_plot_curve.h"
#include "qwt_plot_marker.h"

//------------------------------------------------------------------------------
//------------------------------------------------------------------------------

#define KEEP true

//------------------------------------------------------------------------------
//------------------------------------------------------------------------------

Plot::Plot( int _duree, int _period, double * _timeChannel, double * _yChannel, QWidget * p ) : 
	QwtPlot( p )
{
	setAutoReplot( false );

	duree         = _duree;
	period        = _period;
	double perSec = period / 1000.0;
	double freq   = 1 / perSec;
	nbPoints      = int( duree * freq + 1 );
	realIndex     = 0;
	index         = 0;
	dataX         = new double[nbPoints];
	dataY         = new double[nbPoints];
	timeChannel   = _timeChannel;
	yChannel      = _yChannel;
	double nbPer  = nbPoints - 1;
	dataX[0]       = 0;
	for( int i = 1; i < nbPoints; i++ )
	{
		dataX[i] = dataX[0] + duree * i / nbPer;
		dataY[i] = 0.0;
	}

	courbe = new QwtPlotCurve( "Curve 1" );
	courbe->attach( this );
	courbe->setRawData( dataX, dataY, index );
	setAxisScale( QwtPlot::xBottom, dataX[0], dataX[nbPoints-1] );
	setAxisScale( QwtPlot::yLeft, -15, 15 );

	if( ! KEEP )
	{
		marker = NULL;
	}
	else
	{
		marker = new QwtPlotMarker;
		marker->setValue( QwtDoublePoint( 0, 0 ) );
		marker->setLineStyle(QwtPlotMarker::VLine);
		marker->setLinePen( QPen( Qt::black, 0, Qt::SolidLine ) );
		marker->attach( this );
	}

	startTimer( period );

	setAutoReplot( true );
}

//------------------------------------------------------------------------------
//------------------------------------------------------------------------------

Plot::~Plot()
{
	delete [] dataX;
	delete [] dataY;
}

//------------------------------------------------------------------------------
//------------------------------------------------------------------------------

void Plot::timerEvent( QTimerEvent * )
{
	if( index == nbPoints - 1 )
	{
		dataY[nbPoints-1] = *yChannel;
		dataX[0] = dataX[nbPoints-1];
		for( int i = 1; i < nbPoints; i++ )
		{
			dataX[i] = dataX[0] + duree * i / double( nbPoints - 1 );
		}
		setAxisScale( QwtPlot::xBottom, dataX[0], dataX[nbPoints-1] );
		index = 0;
	}
	dataY[index] = *yChannel;
	if( marker ) marker->setXValue( double( realIndex ) * period / 1000 );
	index++;
	realIndex++;
	courbe->setRawData( dataX, dataY, KEEP ? qMin( realIndex, nbPoints ) : index );
}

//------------------------------------------------------------------------------
//------------------------------------------------------------------------------

