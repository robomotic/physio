
#ifndef __PLOT_H__
#define __PLOT_H__

//------------------------------------------------------------------------------
//------------------------------------------------------------------------------

#include "qwt_plot.h"

class QwtPlotCurve;
class QwtPlotMarker;

//------------------------------------------------------------------------------
//------------------------------------------------------------------------------

class Plot : public QwtPlot
{
	Q_OBJECT

	public:
		Plot( int duree, int period, double * _timeChannel, double * _yChannel, QWidget * p = NULL );
		~Plot();

	protected:
		void timerEvent( QTimerEvent * );

	public:
		QwtPlotCurve  * courbe;
		QwtPlotMarker * marker;

	private:
		int      duree;
		int      period;
		int      nbPoints;
		int      index;
		int      realIndex;
		double * dataX;
		double * dataY;
		double * timeChannel;
		double * yChannel;
};

//------------------------------------------------------------------------------
//------------------------------------------------------------------------------

#endif // __PLOT_H__

